const words = ['Aeroplane','Gasoline','Combustion','Control','Reward','Supreme','Ghana','Justice','League','Orlando','Mushroom',
    'Classroom','Editor','Remote','Kiosk','Container','Germany','France','Holland','Kotoka','Question','Adoption','Vegetation',
    'Provision','Assurance','Pollution','Typing','Follow','Drama','Suggestion','Galaxy','Science','Technology','Onion',
    'Reduction','Production','China','Congo','Kingdom','Sophistication','India','Singapore','Korea','Legend','Chronicle',
    'Quality','Keyboard','Boring','Generous','Housing','Arising','Endulging','Engaging','Dangerous','Nationwide','Apologies',
    'Pledge','Suppose','Canada','Ukraine','Russia','Western','Orleans','Ohio','Boston','Conjunction','Comprehension',
    'Composition','Deep','Maturity','Christmas','Olympics','Warrior','Achievement','Prohibition','Exhibition','Assembly',
    'Moon','Sharpen','Exposure','Release','Landmark','Tropical','Association','Stoppage','Sewage','Advance','Intelligence',
    'Politician','Expectation','Establishment','Organization','Boundary','Internal','External','Provocation','Plantation',
    'Farming','Cultivation','Scientist','Velocity','Acceleration','Motion','Gravity','Concentration','Colloid','Solution',
    'Rusting','Printing','Landlord','Mechanism','Approval','Signatory','Response','Concord','Marine','Aquatic','Aquarium',
    'Accuracy','Accustom','Amphora','Amplitude','Situation','Awareness','Apostrophe','Applaud','Carnival','Savoring','Luminous',
    'Exchange','Foreign','Catastrophe','Measurement','Improvement','Ambiguity','Suppression'
];


function playgameplayAudio(){
        document.querySelector('.gameplay-audio').play();
        document.querySelector('.gameplay-audio').addEventListener('ended', ()=>{
        document.querySelector('.gameplay-audio').play();
    });
    
}


function controlAudio(){
    const mutedAudio = `
    <svg version="1.1" class="game-volume" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
    viewBox="0 0 64 64" style="enable-background:new 0 0 64 64;" xml:space="preserve">
<g>
   <path d="M48.2,27.7c-1.6,0-2.7,1.1-2.7,2.7v26.5L29.5,47c-1.3-0.8-2.9-0.5-3.7,0.8s-0.5,2.9,0.8,3.7l16.1,9.9
    c0.8,0.5,1.9,0.8,2.9,0.8c0.8,0,1.9-0.3,2.7-0.8c1.6-1.1,2.7-2.7,2.7-4.6V30.4C50.9,28.8,49.8,27.7,48.2,27.7z"/>
   <path d="M63.2,2.5c-1.1-1.1-2.7-1.1-3.7,0l-8.6,8.6V7.4c0-1.9-1.1-3.7-2.9-4.8c-1.9-0.8-3.7-0.8-5.6,0.3L25.2,14.1
    c0,0.3-0.3,0.3-0.3,0.3H6.7C2.9,14.3,0,17.3,0,21v24.4c0,3.5,2.9,6.4,6.7,6.4h3.7l-5.4,5.4c-1.1,1.1-1.1,2.7,0,3.7
    c0.5,0.5,1.3,0.8,1.9,0.8s1.3-0.3,1.9-0.8L63.2,6.3C64.3,5.5,64.3,3.6,63.2,2.5z M6.7,46.5c-0.8,0-1.3-0.5-1.3-1.3V20.8
    c0-0.5,0.5-1.1,1.3-1.1h18.2c1.3,0,2.7-0.3,3.7-1.1L45.5,7.4v9.4l-30,29.7H6.7z"/>
</g>
</svg>
    `;

    const playingAudio = `
    <svg version="1.1" class="game-volume" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
    viewBox="0 0 64 64" style="enable-background:new 0 0 64 64;" xml:space="preserve">
<g>
   <path d="M47.3,26.6c-1.1-1.1-2.7-1.1-3.7-0.3c-1.1,1.1-1.1,2.7-0.3,3.7c0.8,1.1,0.8,2.7,0,3.7c-1.1,1.1-0.8,2.7,0.3,3.7
    c0.5,0.5,1.1,0.8,1.9,0.8c0.8,0,1.3-0.3,1.9-0.8C50.2,34.3,50.2,29.5,47.3,26.6z"/>
   <path d="M53.2,22.3c-1.1-1.1-2.7-1.1-3.7-0.3c-1.1,1.1-1.1,2.7-0.3,3.7c2.9,3.2,2.9,8.8,0,12c-1.1,1.1-0.8,2.7,0.3,3.7
    c0.5,0.5,1.1,0.8,1.9,0.8s1.3-0.3,1.9-0.8C58,36.2,58,27.7,53.2,22.3z"/>
   <path d="M58.8,18C57.7,17,56.1,17,55,17.8c-1.1,1.1-1.1,2.7-0.3,3.7c5.1,5.6,5.1,14.7,0,20.3c-1.1,1.1-0.8,2.7,0.3,3.7
    c0.5,0.5,1.1,0.8,1.9,0.8c0.8,0,1.3-0.3,1.9-0.8C65.7,38.1,65.7,25.8,58.8,18z"/>
   <path d="M34.7,11.6c-1.6-1.1-3.7-0.8-5.3,0.3l-11.2,6.7H5.3C2.4,18.6,0,21,0,23.9v16c0,2.9,2.4,5.3,5.3,5.3h12.8l11,6.9
    c0.8,0.5,1.9,0.8,2.9,0.8c0.8,0,1.9-0.3,2.7-0.8c1.6-1.1,2.7-2.7,2.7-4.8V16.2C37.4,14.3,36.3,12.4,34.7,11.6z M32.1,47.7l-11-6.9
    c-0.8-0.5-1.9-0.8-2.9-0.8H5.3v-16h12.8c1.1,0,1.9-0.3,2.9-0.8l11-6.9V47.7z"/>
</g>
</svg>
    `;

    
    const audControlContainer = document.querySelector('.gameplay-volume-control');
    audControlContainer.addEventListener('click', ()=>{

        if(audControlContainer.classList.contains('playing')){
            audControlContainer.innerHTML = mutedAudio;
            audControlContainer.classList.remove('playing');
            document.querySelector('.gameplay-audio').pause();
        }else{
            audControlContainer.innerHTML = playingAudio;
            audControlContainer.classList.add('playing');
            document.querySelector('.gameplay-audio').play();
        }
    })
}

controlAudio();




const currrentWord  = document.querySelector('.show-word');
const countDown     = document.querySelector('.count-number');
const typedWord     = document.querySelector('.typed-word');
const score         = document.querySelector('.score-number');
let docKey          = [];

function randomNum(){
    return Math.floor(Math.random() * 136);
}

scoreIndex = 0;
let timer  = null;


let speedCtn = 2500;

function adjustGameSpeed(){
    let userSpeed = 1;

    document.querySelector('.speed-btn-1').addEventListener('click', ()=>{
        if(speedCtn < 2500){
            speedCtn += 500;
            if(userSpeed > 1){
                userSpeed--;
                document.querySelector('.speed-number').textContent = `${userSpeed}`;
            }    
        }
    })

    document.querySelector('.speed-btn-2').addEventListener('click', ()=>{
            if(speedCtn > 500){
                speedCtn -= 500;
                if(userSpeed < 5){
                    userSpeed++;
            document.querySelector('.speed-number').textContent = `${userSpeed}`;           
            }  
        }
    })
    
    return speedCtn;
}

adjustGameSpeed();


function playerScore(num){
    return num;
}

let starIndex = 5;
    
    function ratePlayerScore(){
        const stars = document.querySelectorAll('.stars svg');
            let scoreText = Number(score.textContent);
                if(scoreText > 0 && scoreText % 5 === 0){
                    if(starIndex > 0 && starIndex < 6){
                        starIndex--;
                            stars[starIndex].classList.add('star');
                }
            }
        }
        

    function displayWord(el, num){
        currrentWord.textContent = el[num];
            let wordLength = (el[num].length + 1);
                const remainingCount = document.querySelector('.count-number');
                    function remainingTime(cnt){
                        remainingCount.textContent = cnt;
        }
    
        

        const lifeBar = document.querySelector('.life-reader');
        lifeBar.style.width = '100%';
        
        function runGame(){
            let lifeNum = 0;
                timer = setInterval(() => {
                    if(wordLength > 0){
                        wordLength--;
                            remainingTime(wordLength);
                    if(wordLength % 1 === 0){
                        lifeNum++;
                            lifeBar.style.width = `${(100 / lifeNum)}%`;
                        if(wordLength <= 1){
                            lifeBar.style.width = '0';
                        }
                    }
                }
                if(remainingCount.textContent === '0'){
                    clearInterval(timer);
                    scoreIndex--;
                    score.textContent = playerScore(scoreIndex);
                    docKey = [];
                    typedWord.textContent = '';
                    displayWord(words, randomNum());
                }
            }, adjustGameSpeed());

        }
        ratePlayerScore();
        runGame();
    }




function displayWarningMessage(){
    const warningIcon    = document.querySelector('.warning');
    const quitWarning    = document.querySelector('.quit-warning');
    const warningMessage = document.querySelector('.warning-message');
    warningIcon.addEventListener('click', ()=>{
        warningMessage.style.display = 'flex';
    })
    quitWarning.addEventListener('click', ()=>{
        warningMessage.style.display = 'none';
    })
}

displayWarningMessage();


function keyValues(){
    const keys = document.querySelectorAll('.key');
    const powerKey = document.querySelector('.kill');
    let m = "";
    for(let i = 0; i < keys.length; i++){
        document.addEventListener('keypress', (e)=>{
            if(e.key === "0"){
                powerKey.classList.add('off');
                location.reload();
            }

            if(e.key.toLocaleUpperCase() === keys[i].textContent){
                docKey.push(keys[i].textContent);
                let text = docKey.join("");
                typedWord.textContent = text;
                keys[i].style.backgroundColor = 'orange';
                m = text.toLocaleUpperCase();
            }else{
                keys[i].style.backgroundColor = '';
            };
        })
    }    

    document.addEventListener('keypress', ()=>{
        if(m === currrentWord.textContent.toUpperCase()){
            scoreIndex++;
            score.textContent = playerScore(scoreIndex);
            clearInterval(timer);
            displayWord(words, randomNum());
            docKey = [];
            typedWord.textContent = '';             
        }else{
            if(currrentWord.textContent.toUpperCase().indexOf(m) === -1){
                scoreIndex--;
                score.textContent = playerScore(scoreIndex);
                clearInterval(timer);
                displayWord(words, randomNum());
                docKey = [];
                typedWord.textContent = '';
            }
        }
    })
}
keyValues();


function gameStartScreen(){
    const slide         = document.querySelector('.color-slide');
    const btn1          = document.querySelector('.slide-btn.btn-1');
    const btn2          = document.querySelector('.slide-btn.btn-2');
    const gameStart     = document.querySelector('.start-btn');
    const keyboard      = document.querySelector('.keyboard');
    const keyBoardSkins = ['rgb(20, 220, 177)','rgb(0, 0, 0)', 'rgb(255, 165, 0)', 'rgb(128, 128, 128)', 'rgb(255, 192, 203)'];
    
    
    let skinKey = 0;
    let slideChange = 0;
    
    function selectSkinRight(){
        if(skinKey < 4){
            skinKey += 1;
        }
        return skinKey;
    }
    
    function selectSkinLeft(){
        if(skinKey > 0){
            skinKey -= 1;
        }
        return skinKey;
    }


    function slidePadLeft(){
        if(slideChange > -280){
            slideChange -= 70;
            slide.style.transform = `translateX(${slideChange}px)`;
            selectSkinRight();
            const colorSkinAudSrc = function (){
                document.querySelector('.select-audio').play();
            }
            colorSkinAudSrc();
        }
    }
    
    function slidePadRight(){
        if(slideChange < 0){
            slideChange += 70;
            slide.style.transform = `translateX(${slideChange}px)`;
            selectSkinLeft();
            const colorSkinAudSrc = function (){
                document.querySelector('.select-audio').play();
            }
            colorSkinAudSrc();
        }
    }
    
    btn1.addEventListener('click', slidePadRight);
    btn2.addEventListener('click', slidePadLeft);

    function applyKeyBoardSkinColor(){
        keyboard.style.backgroundColor = `${keyBoardSkins[skinKey]}`;
        keyboard.style.border          = '5px solid black';
    }

    
    gameStart.addEventListener('click', ()=>{
        applyKeyBoardSkinColor();
        const startIntfc = document.querySelector('.start-interface');
        startIntfc.classList.add('fade');
        startIntfc.addEventListener('animationend', ()=>{
            startIntfc.style.display = 'none';
            playgameplayAudio();
            function countDownToStartGame(){
                const countSpace = document.querySelector('.start-counter');
                let countDwn = 4;
                setInterval(()=>{
                    if(countDwn > 0){
                        countDwn--;
                        countSpace.textContent = countDwn;
                        if(countSpace.textContent === '0'){
                            const countCover = document.querySelector('.game-start-count-down');
                            const overlay    = document.querySelector('.overlay');
                            countCover.classList.add('move');
                            countCover.addEventListener('animationend', ()=>{
                                countCover.style.display = 'none';
                                overlay.style.display = 'none';
                                displayWord(words, randomNum());
                            })
                            }
                    }
                },1000);
            }
            countDownToStartGame();
            })
    })
}
gameStartScreen();






















